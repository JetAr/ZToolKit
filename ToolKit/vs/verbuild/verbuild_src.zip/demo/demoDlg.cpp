// demoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "demo.h"
#include "demoDlg.h"
#include "VersionNo.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif


//---------------------------------------------------------------------
//Get DateTime by Daily Offsets from Year/01/01.
//�ش� �⵵�� 1�� 1�� �� ���� lDays ���� ��¥�� ���Ѵ�.
//---------------------------------------------------------------------
//---------------------------------------------------------------------
//Ÿ�� ������ ���Ѵ�.(get timespan - from inside MFC ctr sources)
//---------------------------------------------------------------------
time_t gettimespan(LONG lDays, int nHours, int nMins, int nSecs) throw()
{
 	time_t tm;
	tm = nSecs + 60* (nMins + 60* (nHours + __int64(24) * lDays));
	return tm;
}

struct tm getdatebyspan(int Year,int lDays)
{
	struct tm tmbase ={0,};
	struct tm tmdate;
	time_t tibase;
	time_t timespan;

	//Make Year/01/01 base date
	tmbase.tm_year = Year - 1900;
	tmbase.tm_mon = 0;//0 to 11
	tmbase.tm_mday = 1;// 1 to 31
	tibase = mktime(&tmbase);
	timespan =  gettimespan(lDays,0,0,0);
	tibase += timespan;

	localtime_s(&tmdate,&tibase);
	return tmdate;
}

char * getdatetime(int which,tm *dtinfo)
{
	static char szdatetime[80]={0,};
#if 0
	SYSTEMTIME systime;
	GetLocalTime(&systime);
	wsprintf(szdatetime,"%4d/%02d/%02d %02d:%02d:%02d",
		        systime.wYear,systime.wMonth,systime.wDay,
				systime.wHour,systime.wMinute,systime.wSecond);
#else
	time_t ltm;
	time_t timespan;
	struct tm psttm;
	ltm = time(NULL);//���ó�¥�� ���Ѵ�.
	localtime_s(&psttm,&ltm);
	*dtinfo = psttm;
	dtinfo->tm_year += 1900;
	dtinfo->tm_mon  += 1;

	//struct tm t2;
	//t2 = getdatebyspan(2007,302);//Get Date by Daily Offset from start of Year.(01/01)

	if(which == -1)
		wsprintf(szdatetime,"%04d-%02d-%02d %02d:%02d:%02d",
		psttm.tm_year+1900,psttm.tm_mon+1,psttm.tm_mday,
		psttm.tm_hour,psttm.tm_min,psttm.tm_sec);
	else if(which == 0)
		wsprintf(szdatetime,"%04d-%02d-%02d",psttm.tm_year+1900,psttm.tm_mon+1,psttm.tm_mday);
	else if(which == 1)
		wsprintf(szdatetime,"%02d:%02d:%02d",psttm.tm_hour,psttm.tm_min,psttm.tm_sec);
#endif
	return szdatetime;
}

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CdemoDlg dialog




CdemoDlg::CdemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CdemoDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CdemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CdemoDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


// CdemoDlg message handlers

BOOL CdemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
#if 1
	char verfile[80];
	char verprdt[80];
	char vermajor[80],verminor[80],verbuildno[80],verextend[80];
	char baseyear[80];
	// TODO: Add extra initialization here
	wsprintf(verfile,   "File Version    : %s",VERSION_FILESTR);
	wsprintf(verprdt,   "Product Version : %s",VERSION_PRODUCTSTR);
	wsprintf(vermajor,  "Major           : %d",VERSION_MAJOR);
	wsprintf(verminor,  "Minor           : %d",VERSION_MINOR);
	wsprintf(verbuildno,"BuildNo         : %d",VERSION_BUILDNO);
	wsprintf(verextend, "Extend          : %d",VERSION_EXTEND);

	SetDlgItemText(IDC_VERFILE,verfile);
	SetDlgItemText(IDC_VERPRDT,verprdt);
	SetDlgItemText(IDC_VERMAJOR,vermajor);
	SetDlgItemText(IDC_VERMINOR,verminor);
	SetDlgItemText(IDC_VERBUILDNO,verbuildno);
	SetDlgItemText(IDC_VEREXTEND,verextend);
#ifdef VERSION_BASEYEAR
	if(VERSION_BASEYEAR != 0){
		wsprintf(baseyear,"This version number is daily basis type BuildNo from %d",VERSION_BASEYEAR);
		SetDlgItemText(IDC_BASEYEAR,baseyear);

		//parse daily basis build number part C in A.B.C.D Format
		//on daily basis build number, the build number represent 5 digits as 'YYDDD'.
		//
		//YY means yearindex from base year,
		//DDD means day index from base day of year(01/01)
        //If verbuild with option -d[baseyear],build number is created as daily basis.
        //otherwise, normal digits mode (of course, shift toward left, -s option available)
		//without -s option, and overflow in each part of A,B,C,D ,do not increasing more. 

        //To add null string to string version data(VERSION_FILESTR,VERSION_PRODUCTSTR),
		//use -u option.

		//for create versionno.h file, use 'verbuild -c' option
        //for set to overflow limits for minimum and maximum , use -b and -e options. 
		//e.g) -b1.0.0.0 -e99.99.99999.99

		//for except increasing file version and product version, remove -xfp option.
        //for individual self increasing file version and product version,
		//use -xFP option,it means indepedent from full version value.

		//you can check daily basis build number via 'verbuild -n[buildno] -d[baseyear] also.

		//How to apply version number build in your Project.
		//First, create your Prjoect.
		// 1. Open .rc file and Cut VERSIONINFO block and paste it in .rc2 file(res folder)
		//    if .rc2 not exist,you create it manually (blank).
		//    if .rc2 is not member of Project files, add to Project.
		//    above of line 'VS_VERSION_INFO VERSIONINFO' in .rc2 file,
		//    add #include "VersionNo.h" ( it is not exists yet).
        // 2. To create initial 'VersionNo.h' , run at command line prompt,
		//    in the same directory as your Project. 
		//    verbuild VersionNo.h -c
        // 3. Add verbuild to Project Build-Event instead VS macro or script,
		//    In Project setting, seledt All Configurations,
		//    In the Command Line field under Post-Build Event(after build),
		//    add as following or with your modified own parameters,

		//    verbuild VersionNo.h *.*.*.+ -d2005 -xFp -b1.0.0.0 -e10.30.9999.100 -s
		//    -> daily basis from 2005,minimum us 1.0.0.0,maximum is 10.30.9999.100
		//       increasing part D digits of A.B.C.D Format,
		//       file version is equal to full version,
		//       product version is self increasing,
		//       if overflow minimum or maximum, shift each part of A.B.C.D
		//       but,in daily basis mode,part C is fixed by daily information
		//       if D is overflow,except C, and then B will be increased.
        //  4. For version information use in your source codes like this demo,
		//     #include "VersionNo.h" in your source and use preprocessors!
		//  Thanks,
		//  krkim(Kyung Rae Kim).

		char buff[80];
		char yearindex[3];
		char dayindex[4];
		int yi,di,year ;

		sprintf(buff,"%05d",VERSION_BUILDNO);
		strncpy(yearindex,buff,2);
		strncpy(dayindex,buff+2,3);
		yi = atoi(yearindex);
		di = atoi(dayindex);

		struct tm today;
		getdatetime(0,&today);

		struct tm t2;
		t2 = getdatebyspan(today.tm_year,di);//Get Date by Daily Offset from start of Year.(01/01)
		year = VERSION_BASEYEAR + yi;

		sprintf(buff,"buildno %5d match to %04d-%02d-%02d.",VERSION_BUILDNO,year,t2.tm_mon + 1,t2.tm_mday); 
		SetDlgItemText(IDC_DAILYBASIS,buff);
	}
#endif
#endif
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CdemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CdemoDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CdemoDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

