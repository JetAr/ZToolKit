/*-----------------------------------------------------------
  VERSION CONTROL BUILD SYSTEM                               
  This header file was created by VERBUILD v1.0.0            
  Copyright(c) 2005-2007 Yeamaec Communication.Co,.Ltd.      
  -----------------------------------------------------------
  You can modify below comments for own purpose!             

  version number is usually A.B.C.D format.                  
  A : major B : minor C : build number D : extend            
  VERBUILD supports two type automatic version number.       
  first is increasing normal digits and second is enhanced   
  increasing normal digits with by daily basis build number. 
  the option -d is for second type by set to digit part C.   
  part C in daily basis set maximum 5 digits build number,   
  For example: today��s build number is 02302:               
  which you can decode as follows:                           
  02  => year: but it is not a direct mapping:               
         if the base year is 2005,��2�� maps to 2007.        
  302 => daily index from 01/01                              
  it also could be described by -d2005 option.               
  for overflow,you can set minimum and maximum version bumber
  specified by given -b and -e option with -s option.        
  in normal digits mode,the overflow sequence is A>B>C>D.    
  in daily basis mode,the overflow sequence is A>B>D.        
  minimum version number set by -b option.                   
  For example, -b1.0.0.0                                     
  maximum version number set by -e option.                   
  For example, -e15.10.99999.90                              
  these minimum and maximum version number not effect part   
  C in daily basis mode.                                     
  For example,if part D overflow,skip C and jump to B.       
  The full version is based on VERSION_FULL commonly.        
  For each file version or product version increasing,       
  use -x option as -xf -xp.                                  
                                                             
  info : http://www.yeamaec.com                              
         krkim@yeamaec.com                                   
-----------------------------------------------------------*/
#ifndef VERSIONNO__H
#define VERSIONNO__H

#define VERSION_FULL           1.0.2305.69

#define VERSION_BASEYEAR       2005
#define VERSION_DATE           "2007-11-02"
#define VERSION_TIME           "18:16:20"

#define VERSION_MAJOR          1
#define VERSION_MINOR          0
#define VERSION_BUILDNO        2305
#define VERSION_EXTEND         69

#define VERSION_FILE           1,0,2305,69
#define VERSION_PRODUCT        1,0,2305,69
#define VERSION_FILESTR        "1,0,2305,69\0"
#define VERSION_PRODUCTSTR     "1,0,2305,69\0"

#endif
