//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by demo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_DEMO_DIALOG                 102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     129
#define IDB_BITMAP2                     131
#define IDC_VERFILE                     1000
#define IDC_VERPRDT                     1001
#define IDC_VERMAJOR                    1002
#define IDC_VERMINOR                    1003
#define IDC_VERBUILDNO                  1004
#define IDC_VEREXTEND                   1005
#define IDC_BASEYEAR                    1006
#define IDC_DAILYBASIS                  1007
#define IDC_VERFILE2                    1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
