// ---------------------------------------------------------------------
// Version Build System - Auto Increasing Version Number
// author : KRKIM In My Company Yeamaec,South of Korea
// http://www.yeamaec.com (under construction)
// yeamaec@hanafos.com, krkim@yeamaec.com
// You may use this source codes for any purpose but leave this notice.
// ---------------------------------------------------------------------

// you may get the new version at:
// http://www.codeguru.com/cpp/w-p/win32/versioning/article.php/c14453/

//Overview
//As you know, Windows Executable Binary Files (EXE, DLL, and so forth) have their own version information.
//This information consists of four positions with two bytes each, such as "xx.xx.xxxxx.xx"
//(it means major.minor.buildno.extend). Already, there are several standalone tools or VS macros 
//to implement automatic version numbering. 
//But, these were not enough to implement more dynamic version numbering.
//So finally, I tried to make a version number build tool myself to support more enhanced functions 
//and to be more useful. 
//This tool, 'VERBUILD ', will help you manage a rather more complex version numbering system more easily.


// i got some information and hints from following sites.
// i say thanks to them,
// http://support.microsoft.com/kb/q237870/
// http://www.codeproject.com/tools/rcstamp.asp
// http://www.codeproject.com/dotnet/build_versioning.asp
// http://blogs.msdn.com/vcblog/archive/2007/09/04/what-compiler-does-the-compiler-team-use-and-decoding-version-numbers.aspx
// http://blog.naver.com/skm1981/20034698796

// for help,verbuild.exe -?


/*  
	History
	2007-11-19	<krkim>    added -r[md] option for daily basis ppsitions.

 */

#include "stdafx.h"
#include <time.h>
#include <errno.h>

#include <iostream>
#include <fstream>
#include <strstream>
#include <string>
#pragma warning(disable : 4996)
#pragma warning(disable : 4267)
using namespace std;

enum EXTEND_CLEAR_BY { BY_NONE,BY_YEAR,BY_MONTH,BY_DAY };
typedef struct{
	int vMajor;
	int vMinor;
	int vBuildNo;
	int vExtend;
}VERSIONINFO;

bool ReadVersion(char const * src,char * dest,VERSIONINFO *verInfo);
bool CopyVersion(char const * src,char * dest,VERSIONINFO *verSrc,VERSIONINFO *verDest);
bool MakeVersion(char const * src,char * dest,VERSIONINFO *verInfo,char const * fmtstr);
bool ProcVersionFile(char const * fileName, char const * fmt = NULL);
bool makeversionfile(char const * fileName);
bool getfiletime(const char * fileName,FILETIME *ftLastWrite);
bool setfiletime(const char * fileName,FILETIME *ftLastWrite);

char const * strUsage =
"  usage: verbuild file <format> [options...]\r\n"
"         verbuild @file [<format>] [options...]\r\n"
"\r\n"
"  file      version header file to update\r\n"
"  @file     list file specify one file on each line, e.g.\r\n"
"            c:\\project1\\versionno.h\r\n"
"            c:\\project2\\versionno.h=*.*.*.+\r\n"
"  <format>  x.x.x.x specifies version number changes. x is one of followings\r\n"
"            * : keep current position   + : increment position by one\r\n"
"            digits : set position to this value  e.g. *.*.71.+\r\n"
"  [options]    \r\n"
"    -l            the specified list files\r\n"
"    -d<baseyear>  daily basis mode.buildno increments by date indexing\r\n"
"                  from base year. e.g. -d2005\r\n"
"    -x<fFpP>      f,F : (f)ile version increment on.\r\n"
"                  p or P : (p)roduct version increment on.\r\n"
"                  f,p(individual increment) F,P(set by full version).\r\n"
"    -b<format>    sets minimum version value for beginning.\r\n"
"    -e<format>    sets maximum version value for ending.\r\n"
"                  The format is xx.xx.xxxxx.xx where each digit's length\r\n"
"                  is a free size.\r\n"
"                  e.g. -e15.10.99999.20 or -e200.99.1000.300 -b1.0.0.0\r\n"
"    -s            overflow shift is turned on \r\n"
"    -n[buildno]   decodes and verify the daily basis build number positions.\r\n"
"                  e.g. version number is 15.0.2304.26,\r\n"
"                  \'verbuild -n2304 -d2005\' outputs \'2007-11-01\'.\r\n"
"    -u            add a null to the string version.\r\n"
"    -c            checks file existence and creates it if it does not exist.\r\n"
"    -t[delay]     no update if not reached in [delay] seconds.\r\n"
"                  the default is 5 seconds. use -t0 for no delay.\r\n" 
"    -r[ymd]       sets a term to reset extend positions in daily basis.\r\n"
"                  every (y)ear,(m)onth or (d)ay. eg. -ry for annually.\r\n"
"    -v            verbose\r\n"
"    -h or -?      for more detailed help,use your VS.NET/VS200X Project!\r\n"
"    example:\r\n"
"     verbuild VersionNo.h -c\r\n"
"     verbuild VersionNo.h *.*.*.+\r\n"
"     verbuild VersionNo.h *.*.*.+ -d2005 -s -rd\r\n"
"     verbuild VersionNo.h *.*.*.+ -d2005 -xFp -b1.0.0.0 -e10.10.2310.12 -s\r\n"
"     verbuild VersionNo.h *.*.*.+ -xFp -b1.0.0.0 -e10.10.2310.12 -s\r\n"
"     verbuild -n2303 -d2005\r\n";

char const * strHelp = 
"\r\n"
" >> Using These Options in a My Visual Studio Project <<\r\n"
"\r\n"
" First of all, either create your Project or open an existing Project.\r\n"
"\r\n"
" Usally,My Project have a .rc file which including .rc2.\r\n"
" The .rc2 is another user-defined resource file more freely from vs-ide.\r\n"
" Following steps are Automatic Version Numbering after each build in the\r\n" 
" Visual Studio Environment:\r\n"
"\r\n"
" Step1.Open the .rc file,cut the VERSIONINFO block and then paste it\r\n"
"  into the .rc2 file.\r\n"
"   -The version block means between \'VS_VERSION_INFO\' and \'END\'.\r\n"
"   -The .rc2 file may be located in the RES Folder in your Project directory.\r\n" 
"   -If .rc2 does not exist, you create it manually by any text editor.\r\n" 
"\r\n"
" Step2.Edit the .rc2 file with VERBUILD preprocessors in VersionNo.h.\r\n"
"   -Above the 'VS_VERSION_INFO VERSIONINFO' line in the .rc2 file,\r\n"
"    add #include \"VersionNo.h\" even if VersionNo.h does not exist yet.\r\n" 
"   -Change version data with VERSION_FILE, VERSION_PRODUCT.\r\n" 
"   -Change string version data with VERSION_FILESTR, VERSION_PRODUCTSTR.\r\n"
"\r\n"
"   ///////////////////////////////////////////////////////////////////////\r\n" 
"   // Version\r\n"
"   // \r\n"
"   #include \"VersionNo.h\"                             <---- Add here!\r\n"
"   VS_VERSION_INFO VERSIONINFO\r\n"
"   FILEVERSION    VERSION_FILE                        <---- Edit here!\r\n"
"   PRODUCTVERSION VERSION_PRODUCT                     <---- Edit Here!\r\n"
"         .\r\n"
"         .\r\n"
"         VALUE \"FileVersion\", VERSION_FILESTR         <---- Edit here!\r\n"
"         .\r\n"
"         VALUE \"ProductVersion\", VERSION_PRODUCTSTR   <---- Edit here!\r\n"
"         .\r\n"
"         .\r\n"
"      BLOCK \"VarFileInfo\"\r\n"
"      BEGIN\r\n"
"        VALUE \"Translation\", 0x412, 1200\r\n"
"     END\r\n"
"   END\r\n"
"\r\n"

" Step3.Create the initial 'VersionNo.h' in the same directory as your Project.\r\n"
"   Run at a command line prompt as:\r\n"
"   \'verbuild VersionNo.h -c\'\r\n"
"   You will find the VersionNo.h file in your Project directory.\r\n"
"   Otherwise,add to the Project's Pre-Build Event for everytime checking file.\r\n"
"\r\n"

" Step4.Add VERBUILD to the Project's Build-Event.\r\n"
"   -In the Project's setting, select All Configurations.\r\n"
"    In the Command Line field under Post-Build Event that called after\r\n"
"    the build, add as Examples or with your modified parameters:\r\n"
"    \"verbuild VersionNo.h *.*.*.+ -d2005 -xFp -b1.0.0.0 -e10.30.9999.100 -s\"\r\n"

"   -For a Pre-Build Event, you can add a command line such as,\r\n"
"    \'verbuild VersionNo.h -c\' if you want. It is not necessary \r\n"
"    if the VersionNo.h file already exists when you run it once.\r\n"
"    With the -c option, the out message is: \r\n"
"    \"Checking Version Number File ...VersionNo.h exists ...\"\r\n"
"   -After each build of your project, you can see something that looks like\r\n"
"    the following:\r\n"
"    \"Updating Version Number File.......\"\r\n"
"\r\n"
" Step5.Use version information in your source files by adding\r\n"
"   #include \"VersionNo.h\"\r\n"
"   As result, the output \'VersionNo.h\" file looks like this\r\n"
"\r\n"
"   #define VERSION_FULL           1.0.2304.4\r\n"
"   #define VERSION_FILE           1,0,2304,4\r\n"
"   #define VERSION_PRODUCT        1,0,2304,4\r\n"
"   #define VERSION_FILESTR        \"1,0,2304,4\"\r\n"
"   #define VERSION_PRODUCTSTR     \"1,0,2304,4\"\r\n"
"\r\n"
" Additional Information\r\n"
"  In ResourceView, by pressing Ctrl+Shift+E, right-click and select the\r\n"
"  resource include menu. When the Resource Includes dialog is shown,\r\n"
"  Add these lines to the Compile-time directives:\r\n"
"    #include \"VersionNo.h\"\r\n"
"    #include \"res\\MyProject.rc2\"\r\n"
"  or\r\n"
"    #include \"res\\MyProject.rc2\" only.\r\n"
"  Including the VersionNo.h file always causes a Post-Build Event because\r\n"
"  the VersionNo.h file is updated by VERBUILD and VS IDE, detecting the\r\n"
"  modification directly even if any resources were not changed.\r\n"
"  (It increments the version on each build.) But, by not including\r\n"
"  VersionNo.h here (only included in the .rc2 file), each build will not\r\n"
"  work until any resources are changed even if VersionNo.h was changed\r\n"
"  already (increments the version when the resource changed).\r\n"
"\r\n"
" To get more information,\r\n"
"  http://www.codeguru.com/cpp/w-p/win32/versioning/article.php/c14453\r\n"
"\r\n"
" Thanks & Regards,\r\n"
" KRKIM                                               yeamaec@hanafos.com\r\n"
"                                                  http://www.yeamaec.com\r\n"
" Copyright(c) 2005-2007 Yeamaec Communication.Co,.Ltd.\r\n\r\n"
"";

char const *    listFile      = NULL;			// single version file (.h), or name of list file
bool            dolistFile  = false;			// list file
char const *    format          = NULL;         // format specifier

bool processListFile = false;       // the file(s) specified are list files, not resource files
bool verbose         = false;       // -v
bool buildno_bydate  = false;       // -d
int  buildno_baseyear = 0;          // year of -d[year]
bool doFile  = false;				// f or F in -f[fFpP]
bool doProduct = false;				// p or P in -f[fFpP]
bool doFilebyFull = false;			// F in -f[fFpP]
bool doProductbyFull = false;		// P in -f[fFpP]
bool doShift = false;				//shift if overflow to higher(no action in daymode by option '-d')
bool checkfile = false;
bool withNull = false;				//str version with null?
int  doClearExtend = BY_NONE;		//clear extend no on daily basis when changed day or month.
char version_min[64] = { 0 };       // "final" version string
char version_max[64] = { 0 };       // "final" version string
int  verifybuildno = 0;
bool verifybuildno_flag = false;
bool help = false;
int  delaytime = 5;//delay time (seconds)

VERSIONINFO *verMax = NULL,*verMin = NULL;

//---------------------------------------------------------------------
//Ÿ�� ������ ���Ѵ�.(get timespan - from inside MFC ctr sources)
//---------------------------------------------------------------------
time_t gettimespan(LONG lDays, int nHours, int nMins, int nSecs) throw()
{
 	time_t tm;
	tm = nSecs + 60* (nMins + 60* (nHours + __int64(24) * lDays));
	return tm;
}

time_t cvtsystime(struct tm * atm,SYSTEMTIME stLocal)
{
	time_t ti;
	atm->tm_sec = (int)stLocal.wSecond;
	atm->tm_min = (int)stLocal.wMinute;
	atm->tm_hour =(int)stLocal.wHour;
	atm->tm_mday = (int)stLocal.wDay;
	atm->tm_mon = (int)stLocal.wMonth - 1;        // tm_mon is 0 based
	atm->tm_year = (int)stLocal.wYear - 1900;     // tm_year is 1900 based
	atm->tm_isdst = -1;

	ti = mktime(atm);
	return ti;
}

//t is timespan struct type as time_t

#define GETDAYS(t)			(LONGLONG)(t/(24*3600))
#define GETTOTALHOURS(t)    (LONGLONG)(t/3600)
#define GETHOURS(t)			(LONG)( GETTOTALHOURS(t)-(GETDAYS(t)*24) ))
#define GETTOTALMINUTES(t)	( t/60 )
#define GETMINUTES(t)		(LONG)( GETTOTALMINUTES(t)-(GETTOTALHOURS(t)*60) )
#define GETTOTALSECONDS(t)  (t)
#define GETSECONDS(t)		(LONG)( GETTOTALSECONDS(t)-(GETTOTALMINUTES(t)*60) )

int checkfiletime(FILETIME *ftLastWrite)//compare filetime with localtime
{
	SYSTEMTIME /*stUTC,*/stLocal;
	SYSTEMTIME stfUTC, stfLocal;

	GetLocalTime(&stLocal);
	//GetSystemTime(&stUTC);
#if 0
	SYSTEMTIME stfLocal2;
	FILETIME ftLocal;
	FileTimeToLocalFileTime((CONST FILETIME*)(ftLastWrite),(FILETIME *)&ftLocal);
	FileTimeToSystemTime(&ftLocal,&stfLocal2);
	//stfLocal2 is equal to stfLocal below routines
#endif
	// Convert the last-write time to local time.
    FileTimeToSystemTime(ftLastWrite, &stfUTC);
    SystemTimeToTzSpecificLocalTime(NULL, &stfUTC, &stfLocal);

	struct tm tm1,tm2;
	time_t t1,t2;
	int timespan;

	t1 = cvtsystime(&tm1,stfLocal);//file
	t2 = cvtsystime(&tm2,stLocal);	//time
	timespan = (int)GETTOTALSECONDS(t2-t1);
	return timespan;
}

//---------------------------------------------------------------------
//Get DateTime by Daily Offsets from Year/01/01.
//�ش� �⵵�� 1�� 1�� �� ���� lDays ���� ��¥�� ���Ѵ�.
//---------------------------------------------------------------------
struct tm getdatebyspan(int Year,int lDays)
{
	struct tm tmbase ={0,};
	struct tm tmdate;
	time_t tibase;
	time_t timespan;

	//Make Year/01/01 base date
	tmbase.tm_year = Year - 1900;
	tmbase.tm_mon = 0;//0 to 11
	tmbase.tm_mday = 1;// 1 to 31
	tibase = mktime(&tmbase);
	timespan =  gettimespan(lDays,0,0,0);
	tibase += timespan;

	localtime_s(&tmdate,&tibase);
	return tmdate;
}

char * getdatetime(int which,tm *dtinfo)//get datatime string
{
	static char szdatetime[80]={0,};
#if 0
	SYSTEMTIME systime;
	GetLocalTime(&systime);
	wsprintf(szdatetime,"%4d/%02d/%02d %02d:%02d:%02d",
		        systime.wYear,systime.wMonth,systime.wDay,
				systime.wHour,systime.wMinute,systime.wSecond);
#else
	time_t ltm;
	//time_t timespan;
	struct tm psttm;
	ltm = time(NULL);//���ó�¥�� ���Ѵ�.
	localtime_s(&psttm,&ltm);
	*dtinfo = psttm;
	dtinfo->tm_year += 1900;
	dtinfo->tm_mon  += 1;

	//struct tm t2;
	//t2 = getdatebyspan(2007,302);//Get Date by Daily Offset from start of Year.(01/01)

	if(which == -1)
		wsprintf(szdatetime,"%04d-%02d-%02d %02d:%02d:%02d",
		psttm.tm_year+1900,psttm.tm_mon+1,psttm.tm_mday,
		psttm.tm_hour,psttm.tm_min,psttm.tm_sec);
	else if(which == 0)
		wsprintf(szdatetime,"%04d-%02d-%02d",psttm.tm_year+1900,psttm.tm_mon+1,psttm.tm_mday);
	else if(which == 1)
		wsprintf(szdatetime,"%02d:%02d:%02d",psttm.tm_hour,psttm.tm_min,psttm.tm_sec);
#endif
	return szdatetime;
}

bool initparameter(int argc, char* argv[])
{
	string msg;

	int i = 1;
	char *p;
	
	while(i < argc){
		p = argv[i];
		msg += " ";
		msg += p;
		if (*p!='-' && *p != '/') {
			if (listFile == NULL) {
				listFile = p;
				if (*listFile=='@') {
					dolistFile = true;
					++listFile;
				}
			}
			else if (format == NULL) {
				format = p;
			}
			else {
				cerr << "Unexpected argument\"" << p << "\"\r\n";
				return false;
			}
			i++;
			continue;
		}

		++p;
		char c = tolower(*p);

		if (c=='l')			processListFile = true;
		else if (c=='v')    verbose = true;
		else if (c=='d'){
			buildno_bydate = true;
			const char *q = p + 1;
			while(*q && (*q == ' ' || *q == '\t')) q++;
			if(*q)
				buildno_baseyear = atoi(q);
			else{
				i++;
				if(i < argc){
					p = argv[i];
					buildno_baseyear = atoi(p);
				}
			}
		}
		else if (c=='x'){
			const char *q = p + 1;
			while(*q && (*q == ' ' || *q == '\t')) q++;
			while(*q){
				if(*q == 'f' || *q == 'F'){// individual increasing or according by FULL Version
					doFile = true; 
					if(*q == 'F')
						doFilebyFull = true;
				}
				else if(*q == 'p' || *q == 'P'){	
					doProduct = true; // individual increasing
					if(*q == 'P')
						doProductbyFull = true;
				}
				q++;
			}
		}
		else if (c=='r'){//clear (reset) D positions(extend positions) when daily basis.
			const char *q = p + 1;
			while(*q && (*q == ' ' || *q == '\t')) q++;
			if(q && tolower(*q) == 'y')   //monthly reset
				doClearExtend = BY_YEAR;
			else if(q && tolower(*q) == 'm')   //monthly reset
				doClearExtend = BY_MONTH;
			else if(q && tolower(*q) == 'd')//daily reset
				doClearExtend = BY_DAY;
		}
		else if (c=='e'){//maximum ending version (max)
			if(!verMax) verMax = new VERSIONINFO;
			ReadVersion(p+1,version_max,verMax);
		}
		else if (c=='b'){//minimum begining version (min)
			if(!verMin) verMin = new VERSIONINFO;
			ReadVersion(p+1,version_min,verMin);				
		}
		else if (c == 's'){ //auto shift
			doShift = true; // shift version for higher
			if (verbose){
				cout <<  "\tshift on " << version_min << "\r\n";
			}
		}
		else if (c == 'u')
			withNull = true;
		else if (c == 'c')
			checkfile = true;//check versionno.h exist,if not,create
		else if (c=='n'){// -n[buildno] to verify & convert daily basis buildno to date/time
			verifybuildno_flag = true;
			verifybuildno = atoi(p+1);
		}
		else if (c == 'h' || c == '?')
			help = true;
		else if (c == 't'){
			delaytime = atoi(p+1);// if over 0,no update until reach to timespan that previous updated filetime.
		}
		else {
			cerr << "Unknown option\"" << p << "\"\r\n";
			return false;
		}
		i++;
	}
	if(help)
		return true;
	if(!verifybuildno_flag){
		if(!checkfile)
			cout << "Updating Version Number File .......\r\n";
		else
			cout << "Checking Version Number File ...";
	}

	if(!checkfile && verbose){
		cout << "  - parameters: " << msg <<"\r\n";
		cout << "  - version file: " << listFile <<"\r\n";
		cout << "  - format(" << format <<")\r\n";
		if(buildno_bydate && buildno_baseyear > 0)
			cout << "  - buildno by daily: on from base year " << buildno_baseyear <<"\r\n";
		if(doFile)
			cout << "  - file version: on " << ((doFilebyFull) ? "by full version" : "by self") << "\r\n";
		if(doProduct)
			cout << "  - product version: on " << ((doProductbyFull) ? "by full version" : "by self") << "\r\n";
		if(doShift)
			cout << "  - overflow shift: on " << "\r\n";
		if(verMax)
			cout << "  - max version: " << version_max << "\r\n";
		if(verMin)
			cout << "  - min version: " << version_min << "\r\n";
	}

    return true;
}

char * getdelimiter(char const * str)
{
	char *delimiters[ ] = {" ,"," .",",","."};
	static char chDelimiter[5] = " ,";
	for(int i = 0; i < sizeof(delimiters) / sizeof(delimiters[0]) ; i++){
		if(strstr(str,delimiters[i])){
			strcpy(chDelimiter,delimiters[i]);
			return chDelimiter;
		}
	}
	return chDelimiter;
}

//---------------------------------------------------------------------
// read version string from src and insert to dest and fill verInfo.
//---------------------------------------------------------------------
bool ReadVersion(char const * src,char * dest,VERSIONINFO *verInfo)
{
    char * p = dest;
    char * verDup = strdup(src);
    char * verStr = strtok(verDup, " .,");
	char * chDelimiter = getdelimiter(src);

	*dest = 0;

    for(int i=0; i<4; ++i) {
        int oldVersion = atoi(verStr);
        int newVersion = oldVersion;
		if(i == 0)	verInfo->vMajor = newVersion;
		else if(i == 1)	verInfo->vMinor  = newVersion;
		else if(i == 2)	verInfo->vBuildNo = newVersion;
		else if(i == 3)	verInfo->vExtend = newVersion;

        itoa(newVersion, p, 10);
        p += strlen(p);

        if (i != 3) {
            strcpy(p,chDelimiter);
            p += strlen(chDelimiter);
            verStr = strtok(NULL, " .,");
        }
    }
    free(verDup);
    return true;
}

//---------------------------------------------------------------------
//verMin�� verMax �����ȿ��� ������ delimiter�� �̿��� �����ѹ��� ����.
//---------------------------------------------------------------------
bool MakeVersion(char const * src,char * dest,VERSIONINFO *verInfo,char const * fmtstr)
{
	if (!fmtstr)
        fmtstr = format;

    char * fmt[4];
    char * fmtDup = strdup(fmtstr);
    fmt[0] = strtok(fmtDup, " .,");
    fmt[1] = strtok(NULL,   " .,");
    fmt[2] = strtok(NULL,   " .,");
    fmt[3] = strtok(NULL,   " .,");

    if (fmt[3] == 0) {
        cerr << "Invalid Format\r\n";
        return false;
    }

	bool changedYear = false;
	bool changedMonth = false;
	bool changedDay = false;
	struct tm today;
	getdatetime(0,&today);

    char * p = dest;
    char * verDup = strdup(src);
    char * verStr = strtok(verDup, " .,");
	char * chDelimiter = getdelimiter(src);

    *dest = 0;

    for(int i=0; i<4; ++i) {
        int oldVersion = atoi(verStr);
        int newVersion = oldVersion;
		int maxVal = 0,minVal = 0;
        char c = fmt[i][0];

        if (strcmp(fmt[i], "*")==0)
            newVersion = oldVersion;
        else if (isdigit(c))
            newVersion = atoi(fmt[i]);
        else if (c=='+' || c=='-') {
            if (isdigit(fmt[i][1]))
                newVersion = oldVersion + atoi(fmt[i]);
            else
                newVersion = oldVersion + ((c=='+') ? 1 : -1);
        }
		switch(i){
			case 0:
				verInfo->vMajor = newVersion;
				verInfo->vMajor = (verMax) ? min(verInfo->vMajor,verMax->vMajor) : verInfo->vMajor;
				verInfo->vMajor = (verMin) ? max(verInfo->vMajor,verMin->vMajor) : verInfo->vMajor;
				break;
			case 1:
				if(!doShift){//none-overflow shift option
					if(verMax) newVersion = min(newVersion,verMax->vMinor);
					if(verMin) newVersion = max(newVersion,verMin->vMinor);
					verInfo->vMinor  = newVersion;
				}
				else{
					maxVal = (verMax) ? verMax->vMinor : newVersion;
					minVal = (verMin) ? verMin->vMinor : newVersion;
					verInfo->vMinor  = newVersion;
					if(newVersion > maxVal){
						verInfo->vMinor = minVal;
						if( fmt[0][0] != '+' ){
							verInfo->vMajor ++;//�������� ����
							verInfo->vMajor = (verMax) ? min(verInfo->vMajor,verMax->vMajor) : verInfo->vMajor;
						}
					}
					if(newVersion < minVal){
						verInfo->vMinor = maxVal;
						if( fmt[0][0] != '-' ){
							verInfo->vMajor --;//�������� ����
							verInfo->vMajor = (verMin) ? max(verInfo->vMajor,verMin->vMajor) : verInfo->vMajor;
						}
					}
				}
				break;
			case 2:
				if(buildno_bydate){
					//YYDDD
					int yearoffsets = today.tm_year - buildno_baseyear;
					int dayoffsets  = today.tm_yday;
					char verno[10];
					sprintf(verno,"%02d%03d",yearoffsets,dayoffsets);
					newVersion = atoi(verno);
					if(newVersion != oldVersion && doClearExtend){//new 2007.11.19
						int yearoffset = oldVersion / 1000; //get YY of YYDDD
						int dayoffset = oldVersion % 1000; //get DDD of YYDDD
						int	year = (buildno_baseyear == 0) ? today.tm_year : buildno_baseyear + yearoffset;

						struct tm t2;
						t2 = getdatebyspan(year,dayoffset);//Get Date by Daily Offset from start of Year.(01/01)
						if((t2.tm_year + 1900) != today.tm_year)
							changedYear = true;
						else if((t2.tm_mon + 1) != today.tm_mon)
							changedMonth = true;
						else if(t2.tm_mday != today.tm_mday)
							changedDay = true;
					}
					verInfo->vBuildNo = newVersion;
					if((!strcmp(fmt[2], "+")) && (!strcmp(fmt[3], "*")))//����ѹ� �����̰� extend�� �״�� �϶�
						fmt[3][0] = '+';
					else if((!strcmp(fmt[2], "-")) && (!strcmp(fmt[3], "*")))//����ѹ� �����̰� extend�� �״�� �϶�
						fmt[3][0] = '-';
				}
				else{
					if(!doShift){//none-overflow shift option
						if(verMax) newVersion = min(newVersion,verMax->vBuildNo);
						if(verMin) newVersion = max(newVersion,verMin->vBuildNo);
						verInfo->vBuildNo  = newVersion;
					}
					else{
						maxVal = (verMax) ? verMax->vBuildNo : newVersion;
						minVal = (verMin) ? verMin->vBuildNo : newVersion;
						verInfo->vBuildNo  = newVersion;
						if(newVersion > maxVal){
							verInfo->vBuildNo = minVal;
							if( fmt[1][0] != '+' ){
								verInfo->vMinor ++;//���̳ʸ� ����
								maxVal = (verMax) ? verMax->vMinor : verInfo->vMinor;
								minVal = (verMin) ? verMin->vMinor : verInfo->vMinor;
								if(verInfo->vMinor > maxVal){
									verInfo->vMinor = minVal;
									if( fmt[0][0] != '+' ){
										verInfo->vMajor ++;//�������� ����
										verInfo->vMajor = (verMax) ? min(verInfo->vMajor,verMax->vMajor) : verInfo->vMajor;
									}
								}
							}
						}
						if(newVersion < minVal){
							verInfo->vBuildNo = maxVal;
							if( fmt[1][0] != '-' ){
								verInfo->vMinor --;//���̳ʸ� ����
								maxVal = (verMax) ? verMax->vMinor : verInfo->vMinor;
								minVal = (verMin) ? verMin->vMinor : verInfo->vMinor;
								if(verInfo->vMinor < minVal){
									verInfo->vMinor = maxVal;
									if( fmt[0][0] != '-' ){
										verInfo->vMajor --;//�������� ����
										verInfo->vMajor = (verMin) ? max(verInfo->vMajor,verMin->vMajor) : verInfo->vMajor;
									}
								}
							}
						}
					}
				}
				break;
			case 3:
				if(buildno_bydate){
					if(!doShift){
						//added 2007.11.19: clear extend on every day or month.
						if((changedMonth && doClearExtend == BY_MONTH) || (changedDay && doClearExtend == BY_DAY) ||
							(changedYear && doClearExtend == BY_YEAR)) 
							newVersion = 0;
						verInfo->vExtend = newVersion;
						verInfo->vExtend = (verMax) ? min(verInfo->vExtend,verMax->vExtend) : verInfo->vExtend;
						verInfo->vExtend = (verMin) ? max(verInfo->vExtend,verMin->vExtend) : verInfo->vExtend;
					}
					else{
						//added 2007.11.19: clear extend on every day or month.
						if((changedMonth && doClearExtend == BY_MONTH) || (changedDay && doClearExtend == BY_DAY) ||
							(changedYear && doClearExtend == BY_YEAR)) 
							newVersion = 0;
						maxVal = (verMax) ? verMax->vExtend : newVersion;
						minVal = (verMin) ? verMin->vExtend : newVersion;
						verInfo->vExtend = newVersion;
						if(newVersion > maxVal){
							verInfo->vExtend = minVal;
							if( fmt[1][0] != '+' ){//����ѹ��� ��¥�Ƿ� �ǳʶڴ�.
								verInfo->vMinor ++;//���̳ʸ� ����
								maxVal = (verMax) ? verMax->vMinor : verInfo->vMinor;
								minVal = (verMin) ? verMin->vMinor : verInfo->vMinor;
								if(verInfo->vMinor > maxVal){
									verInfo->vMinor = minVal;
									if( fmt[0][0] != '+' ){
										verInfo->vMajor ++;//�������� ����
										verInfo->vMajor = (verMax) ? min(verInfo->vMajor,verMax->vMajor) : verInfo->vMajor;
									}
								}
							}
						}
						if(newVersion < minVal){
							verInfo->vExtend = maxVal;
							if( fmt[1][0] != '-' ){//����� ��¥�Ƿ� �ǳʶڴ�.
								verInfo->vMinor --;//���̳ʸ� ����
								maxVal = (verMax) ? verMax->vMinor : verInfo->vMinor;
								minVal = (verMin) ? verMin->vMinor : verInfo->vMinor;
								if(verInfo->vMinor < minVal){
									verInfo->vMinor = maxVal;
									if( fmt[0][0] != '-' ){
										verInfo->vMajor --;//�������� ����
										verInfo->vMajor = (verMin) ? max(verInfo->vMajor,verMin->vMajor) : verInfo->vMajor;
									}
								}
							}
						}
					}
				}	
				else{
					if(!doShift){//none-overflow shift option
						if(verMax) newVersion = min(newVersion,verMax->vExtend);
						if(verMin) newVersion = max(newVersion,verMin->vExtend);
						verInfo->vExtend  = newVersion;
					}
					else{
						maxVal = (verMax) ? verMax->vExtend : newVersion;
						minVal = (verMin) ? verMin->vExtend : newVersion;
						verInfo->vExtend = newVersion;
						if(newVersion > maxVal){
							verInfo->vExtend = minVal;
							if( fmt[2][0] != '+' ){
								verInfo->vBuildNo ++;//����ѹ��� ����
								maxVal = (verMax) ? verMax->vBuildNo : verInfo->vBuildNo;
								minVal = (verMin) ? verMin->vBuildNo : verInfo->vBuildNo;
								if(verInfo->vBuildNo > maxVal){
									verInfo->vBuildNo = minVal;
									if( fmt[1][0] != '+' ){
										verInfo->vMinor ++;//���̳ʸ� ����
										maxVal = (verMax) ? verMax->vMinor : verInfo->vMinor;
										minVal = (verMin) ? verMin->vMinor : verInfo->vMinor;
										if(verInfo->vMinor > maxVal){
											verInfo->vMinor = minVal;
											if( fmt[0][0] != '+' ){
												verInfo->vMajor ++;//�������� ����
												verInfo->vMajor = (verMax) ? min(verInfo->vMajor,verMax->vMajor) : verInfo->vMajor;
											}
										}
									}
								}
							}
						}
						if(newVersion < minVal){
							verInfo->vExtend = maxVal;
							if( fmt[2][0] != '-' ){
								verInfo->vBuildNo --;//����ѹ��� ����
								maxVal = (verMax) ? verMax->vBuildNo : verInfo->vBuildNo;
								minVal = (verMin) ? verMin->vBuildNo : verInfo->vBuildNo;
								if(verInfo->vBuildNo < minVal){
									verInfo->vBuildNo = maxVal;
									if( fmt[1][0] != '-' ){
										verInfo->vMinor --;//���̳ʸ� ����
										maxVal = (verMax) ? verMax->vMinor : verInfo->vMinor;
										minVal = (verMin) ? verMin->vMinor : verInfo->vMinor;
										if(verInfo->vMinor < minVal){
											verInfo->vMinor = maxVal;
											if( fmt[0][0] != '-' ){
												verInfo->vMajor --;//�������� ����
												verInfo->vMajor = (verMin) ? max(verInfo->vMajor,verMin->vMajor) : verInfo->vMajor;
											}
										}
									}
								}
							}
						}
					}
				}
				break;
		}
        if (i != 3) {
            verStr = strtok(NULL, " .,");
        }
		if(i == 3)
		sprintf(dest,"%d%s%d%s%d%s%d",verInfo->vMajor,chDelimiter,
			verInfo->vMinor,chDelimiter,verInfo->vBuildNo,chDelimiter,verInfo->vExtend);
    }
    free(fmtDup);
    free(verDup);
    return true;
}

//---------------------------------------------------------------------
//verFrom ���� ���� ������ delimiter�� �̿��� �����ѹ��� �����ؿ´�.
//---------------------------------------------------------------------
bool CopyVersion(char const * src,char * dest,VERSIONINFO *verSrc,VERSIONINFO *verDest)
{
    char * verDup = strdup(src);
    char * verStr = strtok(verDup, " .,");
	char * chDelimiter = getdelimiter(src);
	
	*verDest = *verSrc;
    *dest = 0;
	sprintf(dest,"%d%s%d%s%d%s%d",verDest->vMajor,chDelimiter,
		verDest->vMinor,chDelimiter,verDest->vBuildNo,chDelimiter,verDest->vExtend);
    free(verDup);
    return true;
}

//---------------------------------------------------------------------
//fileName : specify VersionNo.h
//---------------------------------------------------------------------
bool ProcVersionFile(char const * fileName, char const * fmt)
{
    const int MAXLINELEN = 2048;

	struct _stat buf;
	int fs = _stat( fileName, &buf );
	if(fs != 0 && errno == ENOENT){//file not found
		makeversionfile(fileName);	
		cout << "creating new " <<fileName << "\r\n";	
		return false;
	}
	if(checkfile){
		cout << fileName << " exists" <<"\r\n";
		return false;
	}

	bool fTime;
	int timespan;
	FILETIME ftLastWrite;
	fTime = getfiletime(fileName,&ftLastWrite);
	if(fTime){
		timespan = checkfiletime(&ftLastWrite);

		if(timespan <= delaytime){
			cout << " No update,time span could not be reached to " << delaytime << " delay seconds yet."<<"\r\n";
			return false;
		}
	}

	ifstream is(fileName);
    if (is.fail()) {
        cerr << " cannot open " << fileName << "\r\n";
        return false;
    }
    string result;

    char line[MAXLINELEN];
    char version_full[64] = { 0 };           // "final" version string
    char version_file[64] = { 0 };      // "final" version string
    char version_product[64] = { 0 };   // "final" version string
	
	bool inComment = false;
	bool inFullVersion = false;

	VERSIONINFO verFull,verFile,verPrdt;
	struct tm today;
	getdatetime(0,&today);

    while (!is.eof()) {
        is.getline(line, MAXLINELEN);
        if (is.bad()) {
            cerr << "Error reading " << fileName << "\r\n";
            return false;
        }
		char *p = line;
		while(*p && (*p == ' ' || *p == '\t')) p++;
		//skip comment (only redirect to output)
		if(!strnicmp(p, "//",2) || inComment == true){
			if(inComment && strstr(p, "*/"))
				inComment = false;
			result += line;
			if(!is.eof())
				result += "\n";
			continue;
		}
		else if(strstr(p, "/*")){
			result += line;
			if(!is.eof())
				result += "\n";
			inComment = true;
			if(strstr(p+2, "*/"))
				inComment = false;
			continue;
		}
		else if(strstr(p, "*/")){
			result += line;
			if(!is.eof())
				result += "\n";
			inComment = false;
			continue;
		}
				
        char * dupl = strdup(line);
        char * token1 = strtok(dupl, " \t");
        char * token2 = strtok(NULL, " \t,");  // allow comma for [VALUE "FileVersion",] entry

		if (token1 && token2 && !strcmpi(token1, "#define") && !strcmpi(token2, "VERSION_FULL")) {
            int offset = (int)(token2-dupl) + (int)strlen(token2);
			char *p = line + offset;
			while(*p && (*p == ' ' || *p == '\t')) p++;
            MakeVersion(p,version_full,&verFull,fmt);
            strcpy(p, version_full);
			inFullVersion = true;
        }
        else if (inFullVersion && token1 && token2 && !strcmpi(token1, "#define")) {
            int offset = token2-dupl + strlen(token2);
			char *p = line + offset;
			while(*p && (*p == ' ' || *p == '\t')) p++;
			if(*p == 0 && offset > 0 &&( *(p - 1) != ' ' && *(p - 1) != '\t')) {
				sprintf(p," ");
				p++;
			}
			if(token2 && !strcmpi(token2, "VERSION_BASEYEAR")){
				if(buildno_baseyear != 0){
					sprintf(p, "%d",buildno_baseyear);
				}
				else sprintf(p,"0\0");
			}
			if(token2 && !strcmpi(token2, "VERSION_MAJOR"))
                sprintf(p, "%d",verFull.vMajor);
			if(token2 && !strcmpi(token2, "VERSION_MINOR"))
                sprintf(p, "%d",verFull.vMinor);
			if(token2 && !strcmpi(token2, "VERSION_BUILDNO"))
                sprintf(p, "%d",verFull.vBuildNo);
			if(token2 && !strcmpi(token2, "VERSION_EXTEND"))
                sprintf(p, "%d",verFull.vExtend);

			if(token2 && !strcmpi(token2, "VERSION_DATE"))
				sprintf(p, "\"%s\"",getdatetime(0,&today));
			if(token2 && !strcmpi(token2, "VERSION_TIME"))
				sprintf(p, "\"%s\"",getdatetime(1,&today));
			
			if(token2 && !strcmpi(token2, "VERSION_FILE")){
				if(doFilebyFull)
					CopyVersion(p,version_file,&verFull,&verFile);
				else
					MakeVersion(p,version_file,&verFile,fmt);
				if(doFile){
					strcpy(p, version_file);
				}
			}
			if(token2 && !strcmpi(token2, "VERSION_PRODUCT")){
				if(doProductbyFull)
					CopyVersion(p,version_product,&verFull,&verPrdt);
				else
					MakeVersion(p,version_product,&verPrdt,fmt);
				if(doProduct){
					strcpy(p, version_product);
				}
			}
			if(token2 && !strcmpi(token2, "VERSION_FILESTR")){
				if(doFile){
					if(withNull) sprintf(p, "\"%s\\0\"",version_file);
					else 		 sprintf(p, "\"%s\"",version_file);
				}
			}
			if(token2 && !strcmpi(token2, "VERSION_PRODUCTSTR")){
				if(doProduct)
					if(withNull) sprintf(p, "\"%s\\0\"",version_product);
					else         sprintf(p, "\"%s\"",version_product);
			}
        }
        free(dupl);
		if(is.eof()){
			result += line;
			break;
		}
        result += line;
        result += "\n";
    }

	cout <<  " Full Version: " << version_full<< "\r\n";
	if(doFile)
		cout <<  " File Version: " << version_file<< "\r\n";
	if(doProduct)
		cout <<  " Product Version: " << version_product<< "\r\n";

    // re-write file
    is.close();

    ofstream os(fileName);
    if (os.fail()) {
        cerr << "Cannot write " << fileName << "\r\n";
        return false;
    }
    os.write( &result[0], result.size());
    if (os.fail()) {
        cerr << "Error writing " << fileName << "\r\n";
        return false;
    }
    os.close();
	//if(fTime)//To prevent  VS IDE reload and rebuild available when try to next build without change source codes..
		     //so,we must to return filetime to original time to fake no more updating.
			 //and VS IDE could not detected VersionNo.h was updated,and work on others files.
	//	setfiletime(fileName,&ftLastWrite);
    return true;
}

bool getfiletime(const char * fileName,FILETIME *ftLastWrite)
{
	int flag;
	FILETIME CreationTime,LastAccessTime;
	HANDLE hFile = ::CreateFile(fileName, GENERIC_READ,
	FILE_SHARE_READ, NULL, OPEN_EXISTING, 
	//FILE_ATTRIBUTE_NORMAL,
	FILE_ATTRIBUTE_NORMAL|FILE_ATTRIBUTE_HIDDEN|FILE_ATTRIBUTE_DIRECTORY|
	FILE_ATTRIBUTE_READONLY|FILE_ATTRIBUTE_SYSTEM,
	NULL);

	if(hFile == INVALID_HANDLE_VALUE) 
		return false;
		
	flag = ::GetFileTime((HANDLE)hFile, &CreationTime, &LastAccessTime, ftLastWrite);
	::CloseHandle(hFile);
	return true;
}

bool setfiletime(const char * fileName,FILETIME *ftLastWrite)
{
	int flag;
	FILETIME CreationTime,LastAccessTime,LastWriteTime;
	HANDLE hFile = ::CreateFile(fileName, GENERIC_READ|GENERIC_WRITE,
	FILE_SHARE_READ, NULL, OPEN_EXISTING, 
	//FILE_ATTRIBUTE_NORMAL,
	FILE_ATTRIBUTE_NORMAL|FILE_ATTRIBUTE_HIDDEN|FILE_ATTRIBUTE_DIRECTORY|
	FILE_ATTRIBUTE_READONLY|FILE_ATTRIBUTE_SYSTEM,
	NULL);

	if(hFile == INVALID_HANDLE_VALUE) 
		return false;
		
	flag = ::GetFileTime((HANDLE)hFile, &CreationTime, &LastAccessTime, &LastWriteTime);
	flag = ::SetFileTime((HANDLE)hFile, &CreationTime, &LastAccessTime, ftLastWrite);
	::CloseHandle(hFile);
	return true;
}

void freeglobals()
{
	if(verMax) delete verMax;
	if(verMin) delete verMin;
}

const char *pname[2] =
{
	" verbuild - Version Numbering Build Tool v1.0.1.\r\n",
};
int main(int argc, char* argv[])
{
	if (argc == 1) {
		cout << pname[0];
        cerr << strUsage;
        return 3;
    }

	if (!initparameter(argc,argv)){
		freeglobals();
        return 3;
	}
	if(help){
		cout << pname[0];
        cout << strUsage;

		cout <<  strHelp;
		return 1;
	}
	if(verifybuildno_flag){
		char buff[80];
		char yearindex[3];
		char dayindex[4];
		int yi,di,year ;

		sprintf(buff,"%05d",verifybuildno);
		strncpy(yearindex,buff,2);
		strncpy(dayindex,buff+2,3);
		yi = atoi(yearindex);
		di = atoi(dayindex);

		struct tm today;
		getdatetime(0,&today);

		struct tm t2;
		t2 = getdatebyspan(today.tm_year,di);//Get Date by Daily Offset from start of Year.(01/01)
		if(buildno_baseyear == 0)
			year = today.tm_year;
		else 
			year = buildno_baseyear + yi;

		sprintf(buff,"buildno %05d match to %04d-%02d-%02d.",verifybuildno,year,t2.tm_mon + 1,t2.tm_mday); 
		cout << buff << "\r\n";
		return 1;
	}

    if (!listFile || (!dolistFile && !format)) {
		if(!checkfile){
			cerr << "No formatting options specified\r\n";
			freeglobals();
			return 3;
		}
    }

    bool errorOccured = false;

    if (dolistFile) {
        const int MAXLINELEN = 2048;
        ifstream is(listFile);
        char line[MAXLINELEN];

        while (!is.bad() && !is.eof()) {
            is.getline(line, MAXLINELEN);

            if (*line==0 || *line == ';')
                continue;

            if (verbose)
                cout << line << "\r\n";

            char * eqpos = strchr(line, '=');
            char const * fmt = format;

            if (eqpos) {        // '=' found
                *eqpos = 0;     // Null-terminate the file name
                fmt = eqpos + 1;
            }
            ProcVersionFile(line, fmt);
        }
    }
    else {
        errorOccured = ProcVersionFile(listFile, NULL);
    }
	freeglobals();

	return 0;
}

bool makeversionfile(char const * fileName)
{
	char const * strcontext =
"/*-----------------------------------------------------------\n"
"  VERSION CONTROL BUILD SYSTEM                               \n"
"  This header file was created by VERBUILD v1.0.1            \n"
"  -----------------------------------------------------------\n" 
"  help : verbuild -?                                         \n"
"  info : http://www.yeamaec.com                              \n"
"         yeamaec@hanafos.com ,krkim@yeamaec.com              \n"
"-----------------------------------------------------------*/\n"
"\n"
"#ifndef VERSIONNO__H\n"
"#define VERSIONNO__H\n"
"\n"
"#define VERSION_FULL           1.0.0.0\n"
"\n"
"#define VERSION_BASEYEAR       \n"
"#define VERSION_DATE           \n"
"#define VERSION_TIME           \n"
"\n"
"#define VERSION_MAJOR          1\n"
"#define VERSION_MINOR          0\n"
"#define VERSION_BUILDNO        0\n"
"#define VERSION_EXTEND         0\n"
"\n"
"#define VERSION_FILE           1,0,0,0\n"
"#define VERSION_PRODUCT        1,0,0,0\n"
"#define VERSION_FILESTR        \"1,0,0,0\"\n"
"#define VERSION_PRODUCTSTR     \"1,0,0,0\"\n"
"\n"
"#endif\n";


	string result;
	ofstream os(fileName);
    if (os.fail()) {
        cerr << "Cannot create " << fileName << "\r\n";
        return false;
    }
	result += strcontext ;
    os.write( &result[0], result.size());
    if (os.fail()) {
        cerr << "Error writing " << fileName << "\r\n";
        return false;
    }
    os.close();

	return true;
}

